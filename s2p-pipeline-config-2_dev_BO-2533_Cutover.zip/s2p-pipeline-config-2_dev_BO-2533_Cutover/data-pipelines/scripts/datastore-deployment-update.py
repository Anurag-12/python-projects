from google.cloud import datastore
import sys
import datetime
import json


try:
    if(len(sys.argv)!=5):
        raise Exception("Input arguments where not given correctly") 
    else:
        pipeline_name = sys.argv[1]
        status = sys.argv[2]
        providerOrConsumer = sys.argv[3]
        env = sys.argv[4]
except Exception as error:
  print(error)
  sys.exit(1)

templates = []
modules = []

if "int_s2p_002_tt" in pipeline_name:
    pipeline_name = "int_s2p_002"

# Get Modules
try:
    with open("../" + pipeline_name + "/" + env + "/" + providerOrConsumer + "/" + "main.tf") as fp:
        line = fp.readline()
        while line:
            if "source" and "git" in line:
                line = line.split('//', 1)[-1]
                modules.append(line[:-2])
            line = fp.readline()
except EnvironmentError: # parent of IOError, OSError *and* WindowsError where available
    print ("main.tf not found")

# Get Templates
try:
    with open("../" + pipeline_name + "/" + env + "/" + providerOrConsumer + "/" + "default.tfstate") as fp:
        line = fp.readline()
        while line:
            if ".zip" in line and '"id":' in line:
                line = line.split('/', -1)[-1]
                if line[:-3] not in templates:
                    templates.append(line[:-3])
            if ".jar" in line and '"id":' in line:
                line = line.split('/', -1)[-1]
                if line[:-3] not in templates:
                    templates.append(line[:-3])
            line = fp.readline()

except EnvironmentError: # parent of IOError, OSError *and* WindowsError where available
    print ("default.tfstate not found")


pipeline_name = sys.argv[1]
client = datastore.Client()
key = client.key('Deployments overview', pipeline_name + "-" + providerOrConsumer)

entity = datastore.Entity(key=key)


entity.update({
    'status': status,
    'updated':datetime.datetime.now(),
    'modules':modules,
    'templates':templates,
    })
client.put(entity)
