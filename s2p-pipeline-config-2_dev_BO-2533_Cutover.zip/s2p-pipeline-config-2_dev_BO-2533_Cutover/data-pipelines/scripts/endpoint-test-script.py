from google.cloud import pubsub_v1
from google.cloud import storage
from concurrent.futures import TimeoutError
import datetime
import time 
import sys
import json

# Configurations

try:
    if(len(sys.argv)!=5 and len(sys.argv)!=6):
        raise Exception("Input arguments where not given correctly") 
    else:
        pipeline_name = sys.argv[1]
        env = sys.argv[2]
        consumer_project_id = sys.argv[3]
        provider_project_id = sys.argv[4]
        if(len(sys.argv)==6):
            wait_for_result = int(sys.argv[5])
        else:
            wait_for_result = 120    
except Exception as error:
  print(error)
  sys.exit(1)

path = "../" + pipeline_name + "/" + env + "/config-testing/"
pathTestcases = path + "testcases.json"
pathConfig = path + "config.json"
# Functions used
def get_jsonData_from_file(path):
    with open(path) as json_file:
        file = json.load(json_file)
    
    return file

def publish_to_topic(topic_name,project_id, payload, metadata):
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path((project_id), (topic_name))

    #Callback function.  
    def callback(message_future):
        # When timeout is unspecified, the exception method waits indefinitely.
        if message_future.exception(timeout=30):
            print(f"Publishing message on {topic_name} threw an Exception {message_future.exception()}.")

    message_future = publisher.publish(topic_path, data=str.encode(payload), **metadata)
    message_future.add_done_callback(callback)

def upload_to_bucket(project_id, bucket_name, payload, format, metadata, blobName):
    client = storage.Client(project=project_id)
    blob = client.get_bucket(bucket_name).blob(blobName)
    blob.metadata = metadata
    content_type = "text/xml" if format == "xmlsoap" else "application/" + format
    blob.upload_from_string(payload, content_type)

def get_test_result_from_logging(project_id,subscription_id):

    # Number of seconds the subscriber should listen for messages
    timeout = 5

    subscriber = pubsub_v1.SubscriberClient()
    # The `subscription_path` method creates a fully qualified identifier
    # in the form `projects/{project_id}/subscriptions/{subscription_id}`
    subscription_path = subscriber.subscription_path(consumer_project_id, subscription_id)
    elementsInSubscriber = []

    def callback(message):
        strMessage = message.data.decode("utf-8") 
        elementsInSubscriber.append(strMessage)
        message.ack()

    streaming_pull_future = subscriber.subscribe(subscription_path, callback=callback)

    # Wrap subscriber in a 'with' block to automatically call close() when done.
    with subscriber:
        try:
            # When `timeout` is not set, result() will block indefinitely,
            # unless an exception is encountered first.
            streaming_pull_future.result(timeout=timeout)
        except TimeoutError:
            streaming_pull_future.cancel()

    return elementsInSubscriber


def compare_testcases_with_result(testcases,elementsInSubscriber ):
    failedTests = []
    for testcase in testcases:
        passTest = False
        for result in elementsInSubscriber:
            if testcase in result and testcases[testcase]["identifier"] in result and testcases[testcase]["expectedLoggingResult"] in result:
                passTest= True
        
        if not passTest:
            failedTests.append(testcase)

    if len(failedTests) < 1:
        print("All testcases where sucessfull") 
    else:
        print("All tests where not successful, these failed:")
        for tc in failedTests:
            print("testcase: " + tc)
        raise Exception("Testcases failed")     


#Testing Topic-Endpoint
print("Running automatic E2E functional tests within GCP")
print("Getting configurations from config file")
configs = get_jsonData_from_file(pathConfig)
print("Getting testacases from testacases file")
testcases = get_jsonData_from_file(pathTestcases)

print("Publishing testcases to sources")
for testcase in testcases:
    with open(path + testcases[testcase]["payload"], "r") as payload:
        payloadStr = payload.read()
    if testcases[testcase]["source"]== "topic":
        publish_to_topic(configs["source"]["topic_name"], provider_project_id, payloadStr,testcases[testcase]["metadata"])
        time.sleep(0.0001)
    if testcases[testcase]["source"]== "bucket":
        if testcases[testcase]["type"] == "successfully-sent-resubmission":
            upload_to_bucket(consumer_project_id,configs["resubmission"]["resubmission_bucket"],payloadStr,testcases[testcase]["format"],testcases[testcase]["metadata"],"resubmission/" + testcases[testcase]["payload"])
        else: 
            upload_to_bucket(provider_project_id,configs["source"]["bucket_name"],payloadStr,testcases[testcase]["format"],testcases[testcase]["metadata"],testcases[testcase]["payload"])


print("Trigger resubmission function")
publish_to_topic(configs["resubmission"]["trigger_topic_name"], consumer_project_id, "trigger for test", {"test":"test"})

print("Pausing to wait for testing results")
time.sleep(wait_for_result)

print("Start collecting logs for test results")
elementsInSubscriber = get_test_result_from_logging(consumer_project_id,configs["logging"]["subscription_id"])
print("Stop collecting logs for test results")

if len(elementsInSubscriber) < 1:
    sys.exit('Error retriving log statemets from topic')

print("Compare testcases to test results")
compare_testcases_with_result(testcases,elementsInSubscriber)