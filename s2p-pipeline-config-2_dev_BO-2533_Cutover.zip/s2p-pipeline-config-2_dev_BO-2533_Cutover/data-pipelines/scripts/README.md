# How to deploy a pipeline
To get more information of how these process work see this confluence page: https://confluence.build.ingka.ikea.com/display/DPFW/Framework+Explanation

## Deployment in dev, test, stage
The pipeline can either be the deployed by creating an automatic trigger in Cloud Build or by running a gcloud builds submit command from cloud shell. Four diffrent settings can be set for a deployment by changing the variable _TYPE.

Deploy
```bash
gcloud builds submit . --config data-pipelines/int_s2p_029/dev/cloudbuild.yaml --substitutions=_TYPE=deploy
```

Destroy
```bash
gcloud builds submit . --config data-pipelines/int_s2p_029/dev/cloudbuild.yaml --substitutions=_TYPE=destroy
```

Only destroy dataflow
```bash
gcloud builds submit . --config data-pipelines/int_s2p_029/dev/cloudbuild.yaml --substitutions=_TYPE=destroy-df
```

Pull request
```bash
gcloud builds submit . --config data-pipelines/int_s2p_029/dev/cloudbuild.yaml --substitutions=_TYPE=pull-request
```

## Deployment in prod
Automatic deployment after code has been merged from pull-request.
