# Int_s2p_002 
This page is made to explain how to deploy different int_s2p_002 pipelines.

## List of all int_s2p_002 pipelines.
* int_s2p_002_tt211
* int_s2p_002_tt220
* int_s2p_002_tt260
* int_s2p_002_tt310
* int_s2p_002_tt315
* int_s2p_002_tt320
* int_s2p_002_tt325
* int_s2p_002_tt330
* int_s2p_002_tt390
* int_s2p_002_tt391
* int_s2p_002_tt440
* int_s2p_002_tt441
* int_s2p_002_tt450
* int_s2p_002_tt456
* int_s2p_002_tt457

## How to deploy a single ttyp pipeline.
It can be done by passing the variable TTYP from either Cloud build trigger or Gcloud submit. 

Deploy
```bash
gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=260
```

* gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=211
* gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=220
* gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=260
* gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=310
* gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=315
* gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=320
* gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=325
* gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=330
* gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=390
* gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=391
* gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=440
* gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=441
* gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=450
* gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=456
* gcloud builds submit . --config data-pipelines/int_s2p_002/dev/consumer-sap/cloudbuild.yaml --substitutions=_TYPE=deploy, _TTYP=457


## How to deploy all ttyp pipelines.
Use the cloud build yaml file that triggers all ttyp pipelines. 

```bash
gcloud builds submit . --config data-pipelines/int_s2p_002/dev/cloudbuild_all.yaml --substitutions=_TYPE=deploy
```
